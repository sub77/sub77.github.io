#!/system/bin/sh

# custom busybox installation shortcut
bb=/sbin/bb/busybox;

# Enable Fsync
	echo "Y" > /sys/module/sync/parameters/fsync_enabled

#disable gentle fair sleepers
echo "NO_GENTLE_FAIR_SLEEPERS" > /sys/kernel/debug/sched_features
echo "0" > /sys/kernel/sched/gentle_fair_sleepers

# Enable IntelliThermal V2
echo "Y" > /sys/module/msm_thermal_v2/parameters/enabled
echo "85" > /sys/module/msm_thermal_v2/parameters/core_limit_temp_degC
echo "90" > /sys/module/msm_thermal_v2/parameters/limit_temp_degC
echo "12" > /sys/module/msm_thermal_v2/parameters/core_control_mask

#Simple Gpu Algorithm
echo 1 > /sys/module/simple_gpu_algorithm/parameters/simple_gpu_activate

# Set TCP westwood
	echo "westwood" > /proc/sys/net/ipv4/tcp_congestion_control

# Set IOSched
        echo "zen" > /sys/block/mmcblk0/queue/scheduler

# disable debugging on some modules
	echo "0" > /sys/module/kernel/parameters/initcall_debug
	echo "0" > /sys/module/alarm/parameters/debug_mask
	echo "0" > /sys/module/alarm_dev/parameters/debug_mask
	echo "0" > /sys/module/binder/parameters/debug_mask
	echo "0" > /sys/module/xt_qtaguid/parameters/debug_mask

#Power Mode
 echo "1" > /sys/module/msm_pm/modes/cpu0/retention/idle_enabled
 echo "1" > /sys/module/msm_pm/modes/cpu1/retention/idle_enabled
 echo "1" > /sys/module/msm_pm/modes/cpu2/retention/idle_enabled
 echo "1" > /sys/module/msm_pm/modes/cpu2/retention/idle_enabled
 echo "512" > /sys/block/mmcblk0/bdi/read_ahead_kb



