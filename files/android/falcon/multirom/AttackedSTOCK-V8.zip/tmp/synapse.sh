#!/sbin/sh
rm -f /system/etc/init.d/UKM;
rm -f /system/etc/init.d/UKM_WAKE;
rm -f /system/etc/init.d/N4UKM;
rm -rf /data/UKM
rm -rf /data/N4UKM
rm -f /system/xbin/uci;
rm -f /system/addon.d/UKM.sh;
cp -f /tmp/synapse/data/UKM/UKM /system/etc/init.d/UKM;
cp -f /tmp/synapse/data/UKM/uci /system/xbin/uci;
cp -f /tmp/synapse/data/UKM/UKM.sh /system/addon.d/UKM.sh;
chmod -R 755 /system/etc/init.d/*;
chmod -R 755 /data/UKM/actions/*;
chmod 6755 /system/xbin/uci;
cp -Rf /tmp/synapse/data/UKM /data/;
echo "Synapse Installed";
