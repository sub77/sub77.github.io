#!/system/bin/sh

# custom busybox installation shortcut
bb=/sbin/bb/busybox;

# Enable Fsync
echo "Y" > /sys/module/sync/parameters/fsync_enabled;

# Disable gentle fair sleepers
echo "NO_GENTLE_FAIR_SLEEPERS" > /sys/kernel/debug/sched_features;
echo "0" > /sys/kernel/sched/gentle_fair_sleepers;

# Enable Headset High Performance Mode
echo "1" > /sys/devices/virtual/misc/soundcontrol/highperf_enabled;

# Faux Sound Tweaks
echo "-1" > /sys/kernel/sound_control_3/gpl_headphone_gain;
echo "-1" > /sys/kernel/sound_control_3/gpl_speaker_gain;
echo "0" > /sys/kernel/sound_control_3/gpl_headphone_pa_gain;

# Enable arch power
echo "ARCH_POWER" > /sys/kernel/debug/sched_features;
echo "1" > /sys/kernel/sched/arch_power;

# CPU-Boost settings
echo "40" > /sys/module/cpu_boost/parameters/boost_ms
echo "998400" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "1" > /sys/module/cpu_boost/parameters/hotplug_boost
echo "60" > /sys/module/cpu_boost/parameters/input_boost_ms
echo "998400" > /sys/module/cpu_boost/parameters/sync_threshold
echo "1" > /sys/module/cpu_boost/parameters/hotplug_boost
echo "1" > /sys/module/cpu_boost/parameters/load_based_syncs

# Enable power suspend
echo "3" > /sys/kernel/power_suspend/power_suspend_mode;

# Enable IntelliThermal V2
echo "Y" > /sys/module/msm_thermal_v2/parameters/enabled;
echo "80" > /sys/module/msm_thermal_v2/parameters/core_limit_temp_degC;
echo "85" > /sys/module/msm_thermal_v2/parameters/limit_temp_degC;
echo "12" > /sys/module/msm_thermal_v2/parameters/core_control_mask;
echo "0" > /sys/module/msm_thermal_v2/core_control/enabled;

# GPU Settings
echo "msm-adreno-tz" > /sys/devices/fdb00000.qcom,kgsl-3d0/devfreq/fdb00000.qcom,kgsl-3d0/governor;

# Enable Adreno Idler
echo "Y" > /sys/module/adreno_idler/parameters/adreno_idler_active;

# Set TCP westwood
echo "westwood" > /proc/sys/net/ipv4/tcp_congestion_control;

# Disable KSM
echo "0" > /sys/kernel/mm/ksm/run;

# LMK tweaks
echo "48" > /sys/module/lowmemorykiller/parameters/cost;
echo "12288,15360,18432,21504,24576,30720" > /sys/module/lowmemorykiller/parameters/minfree;

# Virtual Memory tweaks
echo "40" > /proc/sys/vm/dirty_ratio;
echo "10" > /proc/sys/vm/dirty_background_ratio;
echo "400" > /proc/sys/vm/dirty_expire_centisecs;
echo "1000" > /proc/sys/vm/dirty_writeback_centisecs;
echo "80" > /proc/sys/vm/swappiness;
echo "1" > /proc/sys/vm/laptop_mode;  
echo "4285" > /proc/sys/vm/min_free_kbytes;
echo "100" > /proc/sys/vm/vfs_cache_pressure;
echo "8" > /proc/sys/vm/page_cluster;
echo "64 64" > /proc/sys/vm/lowmem_reserve_ratio;
echo "1" > /proc/sys/vm/highmem_is_dirtyable;
echo "1792" > /proc/sys/vm/nr_requests;
echo "1366" > /proc/sys/kernel/random/read_wakeup_threshold;
echo "2048" > /proc/sys/kernel/random/write_wakeup_threshold;

# Disable debugging on some modules
echo "0" > /sys/module/kernel/parameters/initcall_debug;
echo "0" > /sys/module/alarm/parameters/debug_mask;
echo "0" > /sys/module/alarm_dev/parameters/debug_mask;
echo "0" > /sys/module/binder/parameters/debug_mask;
echo "0" > /sys/module/xt_qtaguid/parameters/debug_mask;

# Power Mode
echo "1" > /sys/module/msm_pm/modes/cpu0/retention/idle_enabled;
echo "1" > /sys/module/msm_pm/modes/cpu1/retention/idle_enabled;
echo "1" > /sys/module/msm_pm/modes/cpu2/retention/idle_enabled;
echo "1" > /sys/module/msm_pm/modes/cpu3/retention/idle_enabled;

# Enable dt2w
echo "2" > /sys/android_touch/doubletap2wake;

# Set IOSched
echo "zen" > /sys/block/mmcblk0/queue/scheduler;
echo "128" > /sys/block/mmcblk0/bdi/read_ahead_kb;
